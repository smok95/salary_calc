package com.smok95.salary_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
